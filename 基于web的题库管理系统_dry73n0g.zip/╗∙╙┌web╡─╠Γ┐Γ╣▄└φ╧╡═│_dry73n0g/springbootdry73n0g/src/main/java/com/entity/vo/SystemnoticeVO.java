package com.entity.vo;

import com.entity.SystemnoticeEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
 

/**
 * 系统公告
 * @author 
 * @email 
 * @date 2024-06-14 10:35:38
 */
public class SystemnoticeVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 				
}
