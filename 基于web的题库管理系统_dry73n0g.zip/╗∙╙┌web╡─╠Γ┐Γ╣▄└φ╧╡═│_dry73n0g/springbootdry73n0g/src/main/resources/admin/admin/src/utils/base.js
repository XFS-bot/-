const base = {
    get() {
        return {
            url : "http://localhost:8080/springbootdry73n0g/",
            name: "springbootdry73n0g",
            // 退出到首页链接
            indexUrl: ''
        };
    },
    getProjectName(){
        return {
            projectName: "基于web的题库管理系统"
        } 
    }
}
export default base
